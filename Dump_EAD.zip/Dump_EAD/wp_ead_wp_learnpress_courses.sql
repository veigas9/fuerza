-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: wp_ead
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_learnpress_courses`
--

DROP TABLE IF EXISTS `wp_learnpress_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_learnpress_courses` (
  `ID` bigint unsigned NOT NULL,
  `json` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `price_to_sort` float DEFAULT NULL,
  `is_sale` int DEFAULT '0',
  `post_author` bigint unsigned DEFAULT NULL,
  `post_date_gmt` datetime DEFAULT NULL,
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `menu_order` int DEFAULT '0',
  `lang` varchar(20) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `post_title` (`post_title`(191)),
  KEY `post_status` (`post_status`),
  KEY `post_name` (`post_name`),
  KEY `id_status` (`ID`,`post_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_learnpress_courses`
--

LOCK TABLES `wp_learnpress_courses` WRITE;
/*!40000 ALTER TABLE `wp_learnpress_courses` DISABLE KEYS */;
INSERT INTO `wp_learnpress_courses` VALUES (1186,'{\"ID\":1186,\"post_author\":\"1\",\"post_date_gmt\":\"2024-11-11 03:34:20\",\"post_title\":\"PHP Básico\",\"post_status\":\"publish\",\"post_name\":\"php-basico\",\"price_to_sort\":150,\"is_sale\":0,\"lang\":null,\"author\":{\"ID\":\"1\",\"user_login\":0,\"user_nicename\":\"andreveigas\",\"user_email\":\"l.andreveigas@gmail.com\",\"user_url\":null,\"user_register\":\"\",\"display_name\":\"Andreveigas\",\"meta_data\":{},\"image_url\":\"\"},\"meta_data\":{\"_lp_regular_price\":\"150\",\"_lp_sale_price\":\"\",\"_lp_price\":\"0\",\"_lp_info_extra_fast_query\":\"{\\\"first_item_id\\\":0,\\\"total_items\\\":{\\\"count_items\\\":null,\\\"lp_lesson\\\":null,\\\"lp_quiz\\\":null},\\\"sections_items\\\":[]}\",\"_lp_sale_start\":false,\"_lp_sale_end\":false,\"_lp_allow_course_repurchase\":\"no\",\"_lp_offline_course\":\"no\",\"_lp_duration\":\"0 week\",\"_lp_block_expire_duration\":\"no\",\"_lp_block_finished\":\"no\",\"_lp_course_repurchase_option\":\"reset\",\"_lp_level\":\"\",\"_lp_students\":100,\"_lp_max_students\":\"0\",\"_lp_retake_count\":\"0\",\"_lp_has_finish\":\"yes\",\"_lp_featured\":\"no\",\"_lp_featured_review\":\"\",\"_lp_external_link_buy_course\":\"\",\"_lp_offline_lesson_count\":10,\"_lp_deliver_type\":\"private_1_1\",\"_lp_address\":\"\",\"_lp_no_required_enroll\":\"no\",\"_lp_requirements\":[\"Interessante já ter cursado Lógica de Programação\"],\"_lp_target_audiences\":[],\"_lp_key_features\":[],\"_lp_faqs\":[],\"_lp_course_result\":\"evaluate_lesson\",\"_lp_passing_condition\":80,\"post_author\":\"1\",\"_lp_course_material\":null,\"_lp_final_quiz\":\"1195\"},\"image_url\":\"http:\\/\\/localhost\\/ead\\/wp-content\\/uploads\\/2024\\/11\\/PHP-logo-1.png\",\"permalink\":\"\",\"categories\":[{\"term_id\":28,\"name\":\"Tecnologia\",\"slug\":\"tecnologia\",\"term_group\":0,\"term_taxonomy_id\":28,\"taxonomy\":\"course_category\",\"description\":\"\",\"parent\":0,\"count\":1,\"filter\":\"raw\"}],\"tags\":[],\"post_excerpt\":\"\",\"first_item_id\":1189,\"total_items\":{\"count_items\":\"4\",\"lp_lesson\":\"3\",\"lp_quiz\":\"1\"},\"sections_items\":[{\"id\":\"1\",\"section_id\":\"1\",\"order\":\"1\",\"section_order\":\"1\",\"title\":\"Modulo 1\",\"section_name\":\"Modulo 1\",\"description\":\"\",\"section_description\":\"\",\"items\":[{\"id\":\"1189\",\"order\":\"0\",\"type\":\"lp_lesson\",\"title\":\"Introdução ao PHP\",\"preview\":false},{\"id\":\"1190\",\"order\":\"1\",\"type\":\"lp_lesson\",\"title\":\"Fundamentos da linguagem\",\"preview\":false},{\"id\":\"1191\",\"order\":\"2\",\"type\":\"lp_lesson\",\"title\":\"Montando Ambiente de desenvolvimento\",\"preview\":false},{\"id\":\"1195\",\"order\":\"3\",\"type\":\"lp_quiz\",\"title\":\"Verificar aprendizado\",\"preview\":false}]}]}',150,0,1,'2024-11-11 03:34:20','>Curso de desenvolimento PHP básico...','PHP Básico','publish','php-basico',0,NULL),(1246,'{\"ID\":1246,\"post_author\":\"1\",\"post_date_gmt\":\"2024-11-11 17:00:44\",\"post_title\":\"Lógica de Programação\",\"post_status\":\"publish\",\"post_name\":\"logica-de-programacao\",\"price_to_sort\":0,\"is_sale\":0,\"lang\":null,\"author\":{\"ID\":\"1\",\"user_login\":0,\"user_nicename\":\"andreveigas\",\"user_email\":\"l.andreveigas@gmail.com\",\"user_url\":null,\"user_register\":\"\",\"display_name\":\"Andreveigas\",\"meta_data\":{},\"image_url\":\"\"},\"meta_data\":{\"_lp_regular_price\":\"\",\"_lp_sale_price\":\"\",\"_lp_price\":\"0\",\"_lp_info_extra_fast_query\":\"{\\\"first_item_id\\\":0,\\\"total_items\\\":{\\\"count_items\\\":\\\"0\\\",\\\"lp_lesson\\\":\\\"0\\\",\\\"lp_quiz\\\":\\\"0\\\"},\\\"sections_items\\\":[]}\",\"_lp_sale_start\":false,\"_lp_sale_end\":false,\"_lp_allow_course_repurchase\":\"no\",\"_lp_offline_course\":\"no\",\"_lp_duration\":\"10 week\",\"_lp_block_expire_duration\":\"no\",\"_lp_block_finished\":\"yes\",\"_lp_course_repurchase_option\":\"reset\",\"_lp_level\":\"\",\"_lp_students\":\"0\",\"_lp_max_students\":\"0\",\"_lp_retake_count\":\"0\",\"_lp_has_finish\":\"yes\",\"_lp_featured\":\"no\",\"_lp_featured_review\":\"\",\"_lp_external_link_buy_course\":\"\",\"_lp_offline_lesson_count\":10,\"_lp_deliver_type\":\"private_1_1\",\"_lp_address\":\"\",\"_lp_no_required_enroll\":\"no\",\"_lp_requirements\":[],\"_lp_target_audiences\":[],\"_lp_key_features\":[],\"_lp_faqs\":[],\"_lp_course_result\":\"evaluate_lesson\",\"_lp_passing_condition\":80,\"post_author\":\"\",\"_lp_course_material\":null,\"_lp_final_quiz\":0},\"image_url\":\"http:\\/\\/localhost\\/ead\\/wp-content\\/uploads\\/2024\\/11\\/logica.jpg\",\"permalink\":\"\",\"categories\":[{\"term_id\":28,\"name\":\"Tecnologia\",\"slug\":\"tecnologia\",\"term_group\":0,\"term_taxonomy_id\":28,\"taxonomy\":\"course_category\",\"description\":\"\",\"parent\":0,\"count\":2,\"filter\":\"raw\"}],\"tags\":[],\"post_excerpt\":\"\",\"first_item_id\":1248,\"total_items\":{\"count_items\":\"1\",\"lp_lesson\":\"1\",\"lp_quiz\":\"0\"},\"sections_items\":[{\"id\":\"2\",\"section_id\":\"2\",\"order\":\"1\",\"section_order\":\"1\",\"title\":\"Módulo 1\",\"section_name\":\"Módulo 1\",\"description\":\"\",\"section_description\":\"\",\"items\":[{\"id\":\"1248\",\"order\":\"0\",\"type\":\"lp_lesson\",\"title\":\"O que são algoritimos\",\"preview\":false}]}]}',0,0,1,'2024-11-11 17:00:44','','Lógica de Programação','publish','logica-de-programacao',0,NULL);
/*!40000 ALTER TABLE `wp_learnpress_courses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-13 14:33:56
