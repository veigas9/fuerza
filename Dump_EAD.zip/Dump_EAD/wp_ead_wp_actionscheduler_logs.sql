-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: wp_ead
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_actionscheduler_logs`
--

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_actionscheduler_logs`
--

LOCK TABLES `wp_actionscheduler_logs` WRITE;
/*!40000 ALTER TABLE `wp_actionscheduler_logs` DISABLE KEYS */;
INSERT INTO `wp_actionscheduler_logs` VALUES (1,10,'ação criada','2024-11-11 01:42:42','2024-11-10 22:42:42'),(2,11,'ação criada','2024-11-11 01:42:45','2024-11-10 22:42:45'),(3,11,'ação iniciada por WP Cron','2024-11-11 01:43:49','2024-11-10 22:43:49'),(4,11,'ação completa por WP Cron','2024-11-11 01:43:49','2024-11-10 22:43:49'),(5,12,'ação criada','2024-11-11 01:43:49','2024-11-10 22:43:49'),(6,10,'ação iniciada por WP Cron','2024-11-11 01:43:49','2024-11-10 22:43:49'),(7,10,'ação completa por WP Cron','2024-11-11 01:43:49','2024-11-10 22:43:49'),(8,13,'ação criada','2024-11-11 01:45:11','2024-11-10 22:45:11'),(9,14,'ação criada','2024-11-11 01:45:11','2024-11-10 22:45:11'),(10,13,'ação iniciada por WP Cron','2024-11-11 01:45:44','2024-11-10 22:45:44'),(11,13,'ação completa por WP Cron','2024-11-11 01:45:54','2024-11-10 22:45:54'),(12,14,'ação iniciada por Async Request','2024-11-11 01:46:32','2024-11-10 22:46:32'),(13,14,'ação completa por Async Request','2024-11-11 01:46:32','2024-11-10 22:46:32'),(14,15,'ação criada','2024-11-11 02:30:47','2024-11-10 23:30:47'),(15,16,'ação criada','2024-11-11 02:30:47','2024-11-10 23:30:47'),(16,15,'ação iniciada por Async Request','2024-11-11 02:30:55','2024-11-10 23:30:55'),(17,15,'ação malsucedida por Async Request: Scheduled action for woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications will not be executed as no callbacks are registered.','2024-11-11 02:30:55','2024-11-10 23:30:55'),(18,16,'ação iniciada por Async Request','2024-11-11 02:30:55','2024-11-10 23:30:55'),(19,16,'ação completa por Async Request','2024-11-11 02:30:55','2024-11-10 23:30:55'),(20,17,'ação criada','2024-11-11 02:44:40','2024-11-10 23:44:40'),(21,18,'ação criada','2024-11-11 02:45:13','2024-11-10 23:45:13'),(22,18,'ação iniciada por WP Cron','2024-11-11 02:45:47','2024-11-10 23:45:47'),(23,18,'ação completa por WP Cron','2024-11-11 02:45:47','2024-11-10 23:45:47'),(24,17,'ação iniciada por WP Cron','2024-11-11 02:45:47','2024-11-10 23:45:47'),(25,17,'ação completa por WP Cron','2024-11-11 02:45:47','2024-11-10 23:45:47'),(26,19,'ação criada','2024-11-11 03:03:58','2024-11-11 00:03:58'),(27,19,'ação iniciada por WP Cron','2024-11-11 03:04:02','2024-11-11 00:04:02'),(28,19,'ação completa por WP Cron','2024-11-11 03:04:03','2024-11-11 00:04:03'),(29,20,'ação criada','2024-11-11 03:15:53','2024-11-11 00:15:53'),(30,20,'ação iniciada por WP Cron','2024-11-11 03:17:10','2024-11-11 00:17:10'),(31,20,'ação completa por WP Cron','2024-11-11 03:17:10','2024-11-11 00:17:10'),(32,21,'ação criada','2024-11-11 03:17:11','2024-11-11 00:17:11'),(33,21,'ação iniciada por WP Cron','2024-11-11 03:18:26','2024-11-11 00:18:26'),(34,21,'ação malsucedida por WP Cron: Scheduled action for action_scheduler/migration_hook will not be executed as no callbacks are registered.','2024-11-11 03:18:26','2024-11-11 00:18:26'),(35,22,'ação criada','2024-11-11 03:45:49','2024-11-11 00:45:49'),(36,22,'ação iniciada por WP Cron','2024-11-11 03:45:53','2024-11-11 00:45:53'),(37,22,'ação completa por WP Cron','2024-11-11 03:45:54','2024-11-11 00:45:54'),(38,23,'ação criada','2024-11-11 16:50:21','2024-11-11 13:50:21'),(39,23,'ação iniciada por WP Cron','2024-11-11 16:50:42','2024-11-11 13:50:42'),(40,23,'ação completa por WP Cron','2024-11-11 16:50:42','2024-11-11 13:50:42'),(41,24,'ação criada','2024-11-11 16:56:23','2024-11-11 13:56:23'),(42,25,'ação criada','2024-11-11 16:56:23','2024-11-11 13:56:23'),(43,26,'ação criada','2024-11-11 16:56:23','2024-11-11 13:56:23'),(44,27,'ação criada','2024-11-11 16:56:23','2024-11-11 13:56:23'),(45,28,'ação criada','2024-11-11 16:56:23','2024-11-11 13:56:23'),(46,29,'ação criada','2024-11-11 16:56:23','2024-11-11 13:56:23'),(47,30,'ação criada','2024-11-11 16:56:23','2024-11-11 13:56:23'),(48,31,'ação criada','2024-11-11 16:56:23','2024-11-11 13:56:23'),(49,24,'ação iniciada por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(50,24,'ação completa por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(51,25,'ação iniciada por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(52,25,'ação completa por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(53,26,'ação iniciada por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(54,26,'ação completa por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(55,27,'ação iniciada por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(56,27,'ação completa por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(57,28,'ação iniciada por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(58,28,'ação completa por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(59,29,'ação iniciada por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(60,29,'ação completa por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(61,30,'ação iniciada por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(62,30,'ação completa por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(63,31,'ação iniciada por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(64,31,'ação completa por WP Cron','2024-11-11 16:56:44','2024-11-11 13:56:44'),(65,32,'ação criada','2024-11-11 16:58:57','2024-11-11 13:58:57'),(66,32,'ação iniciada por WP Cron','2024-11-11 16:59:45','2024-11-11 13:59:45'),(67,32,'ação completa por WP Cron','2024-11-11 16:59:45','2024-11-11 13:59:45'),(68,12,'ação iniciada por WP Cron','2024-11-12 17:59:38','2024-11-12 14:59:38'),(69,12,'ação completa por WP Cron','2024-11-12 17:59:38','2024-11-12 14:59:38'),(70,33,'ação criada','2024-11-12 17:59:38','2024-11-12 14:59:38');
/*!40000 ALTER TABLE `wp_actionscheduler_logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-13 14:34:05
