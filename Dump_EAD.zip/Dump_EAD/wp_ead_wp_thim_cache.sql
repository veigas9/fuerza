-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: wp_ead
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_thim_cache`
--

DROP TABLE IF EXISTS `wp_thim_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_thim_cache` (
  `key_cache` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `expiration` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`key_cache`),
  UNIQUE KEY `key_cache` (`key_cache`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_thim_cache`
--

LOCK TABLES `wp_thim_cache` WRITE;
/*!40000 ALTER TABLE `wp_thim_cache` DISABLE KEYS */;
INSERT INTO `wp_thim_cache` VALUES ('learn_press/course/1186/total-students-enrolled-or-purchased','1','0'),('learn_press/course/1246/total-students-enrolled-or-purchased','0','0'),('learn_press/settings/lp_settings','{\"learn_press_become_a_teacher_page_id\":\"1184\",\"learn_press_check_tables\":\"yes\",\"learn_press_checkout_page_id\":\"1179\",\"learn_press_course_base\":\"\\/curso\",\"learn_press_course_base_type\":\"custom\",\"learn_press_course_category_base\":\"categoria-curso\",\"learn_press_course_tag_base\":\"curso-tag\",\"learn_press_courses_page_id\":\"1181\",\"learn_press_currency\":\"BRL\",\"learn_press_currency_pos\":\"left\",\"learn_press_debug\":\"no\",\"learn_press_decimals_separator\":\",\",\"learn_press_emails_new-order-admin\":{\"enable\":\"no\",\"subject\":\"New order placed on {{order_date}}\",\"heading\":\"New user order\",\"email_content\":{\"plain\":\"== {{header}} ==\\r\\n\\r\\n** New order placed by \\\"{{order_user_name}}\\\" **\\r\\n\\r\\n{{order_items_table}}\\r\\n\\r\\n== {{footer}} ==\\t\\t\\t\\t\\t\\t\\t\\t\",\"html\":\"<p><span style=\\\"vertical-align: inherit;\\\"><span style=\\\"vertical-align: inherit;\\\">{{cabe\\u00e7alho}}<\\/span><\\/span><\\/p>\\r\\n<p><span style=\\\"vertical-align: inherit;\\\"><span style=\\\"vertical-align: inherit;\\\">Novo pedido feito por <\\/span><\\/span><strong><span style=\\\"vertical-align: inherit;\\\"><span style=\\\"vertical-align: inherit;\\\">{{order_user_name}}<\\/span><\\/span><\\/strong><\\/p>\\r\\n<p><span style=\\\"vertical-align: inherit;\\\"><span style=\\\"vertical-align: inherit;\\\">{{tabela_de_itens_do_pedido}} {{rodap\\u00e9}}<\\/span><\\/span><\\/p>\"}},\"learn_press_enable_gutenberg_course\":\"no\",\"learn_press_enable_gutenberg_lesson\":\"no\",\"learn_press_enable_gutenberg_question\":\"no\",\"learn_press_enable_gutenberg_quiz\":\"no\",\"learn_press_instructor_registration\":\"yes\",\"learn_press_instructors_page_id\":\"1182\",\"learn_press_lesson_slug\":\"licoes\",\"learn_press_logout_redirect_page_id\":\"974\",\"learn_press_navigation_position\":\"yes\",\"learn_press_number_of_decimals\":\"2\",\"learn_press_paypal\":{\"paypal_email\":\"l.andreveigas@gmail.com\",\"enable\":\"yes\"},\"learn_press_primary_color\":\"#ffb606\",\"learn_press_profile_endpoints\":{\"courses\":\"cursos\",\"my-courses\":\"meus-cursos\",\"quizzes\":\"quizzes\",\"orders\":\"ordem\",\"order-details\":\"ordenar-detalhes\",\"settings\":\"configuracoes\",\"settings-basic-information\":\"informacoes-basicas\",\"settings-avatar\":\"avatar\",\"settings-change-password\":\"alterar-senha\",\"settings-privacy\":\"privacidade\"},\"learn_press_profile_page_id\":\"1180\",\"learn_press_publish_profile\":\"no\",\"learn_press_quiz_slug\":\"quizzes\",\"learn_press_secondary_color\":\"#442e66\",\"learn_press_setup_wizard_completed\":\"yes\",\"learn_press_single_instructor_page_id\":\"1183\",\"learn_press_term_conditions_page_id\":\"1185\",\"learn_press_thousands_separator\":\".\",\"learn_press_width_container\":\"1290px\"}','0'),('learn_press/user-items/0/1246/lp_course','null','0'),('learn_press/user-items/1/1186/lp_course','{\"user_item_id\":\"1\",\"user_id\":\"1\",\"item_id\":\"1186\",\"item_type\":\"lp_course\",\"status\":\"enrolled\",\"graduation\":\"in-progress\",\"ref_id\":\"1194\",\"ref_type\":\"lp_order\",\"start_time\":\"2024-11-11 03:35:25\",\"end_time\":null}','0'),('learn_press/user-items/1/1246/lp_course','null','0');
/*!40000 ALTER TABLE `wp_thim_cache` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-13 14:34:00
