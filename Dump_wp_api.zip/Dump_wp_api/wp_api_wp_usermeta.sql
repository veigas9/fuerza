-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: wp_api
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wp_usermeta`
--

DROP TABLE IF EXISTS `wp_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wp_usermeta`
--

LOCK TABLES `wp_usermeta` WRITE;
/*!40000 ALTER TABLE `wp_usermeta` DISABLE KEYS */;
INSERT INTO `wp_usermeta` VALUES (1,1,'nickname','Andreveigas'),(2,1,'first_name',''),(3,1,'last_name',''),(4,1,'description',''),(5,1,'rich_editing','true'),(6,1,'syntax_highlighting','true'),(7,1,'comment_shortcuts','false'),(8,1,'admin_color','fresh'),(9,1,'use_ssl','0'),(10,1,'show_admin_bar_front','true'),(11,1,'locale',''),(12,1,'wp_capabilities','a:1:{s:13:\"administrator\";b:1;}'),(13,1,'wp_user_level','10'),(14,1,'dismissed_wp_pointers',''),(15,1,'show_welcome_panel','1'),(16,1,'session_tokens','a:2:{s:64:\"942447726b9fa151fc6a9f9d6cba05e6afca2e6daa5ce97bc31538751f8eaad5\";a:4:{s:10:\"expiration\";i:1731531489;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36\";s:5:\"login\";i:1731358689;}s:64:\"8e72eec89cd754cea5a04a66425fdec4b238f046be4f0d32446e0ac30efc3f75\";a:4:{s:10:\"expiration\";i:1731650678;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:111:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36\";s:5:\"login\";i:1731477878;}}'),(17,1,'wp_dashboard_quick_press_last_post_id','5'),(18,2,'nickname','andre@email.com'),(19,2,'first_name','andre@email.com'),(20,2,'last_name',''),(21,2,'description',''),(22,2,'rich_editing','true'),(23,2,'syntax_highlighting','true'),(24,2,'comment_shortcuts','false'),(25,2,'admin_color','fresh'),(26,2,'use_ssl','0'),(27,2,'show_admin_bar_front','true'),(28,2,'locale',''),(29,2,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(30,2,'wp_user_level','0'),(31,3,'nickname','luis@email.com'),(32,3,'first_name',''),(33,3,'last_name',''),(34,3,'description',''),(35,3,'rich_editing','true'),(36,3,'syntax_highlighting','true'),(37,3,'comment_shortcuts','false'),(38,3,'admin_color','fresh'),(39,3,'use_ssl','0'),(40,3,'show_admin_bar_front','true'),(41,3,'locale',''),(42,3,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(43,3,'wp_user_level','0'),(44,4,'nickname','pedro@email.com'),(45,4,'first_name','mario'),(46,4,'last_name',''),(47,4,'description',''),(48,4,'rich_editing','true'),(49,4,'syntax_highlighting','true'),(50,4,'comment_shortcuts','false'),(51,4,'admin_color','fresh'),(52,4,'use_ssl','0'),(53,4,'show_admin_bar_front','true'),(54,4,'locale',''),(55,4,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(56,4,'wp_user_level','0'),(57,5,'nickname','teste@email.com'),(58,5,'first_name','andre'),(59,5,'last_name',''),(60,5,'description',''),(61,5,'rich_editing','true'),(62,5,'syntax_highlighting','true'),(63,5,'comment_shortcuts','false'),(64,5,'admin_color','fresh'),(65,5,'use_ssl','0'),(66,5,'show_admin_bar_front','true'),(67,5,'locale',''),(68,5,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(69,5,'wp_user_level','0'),(70,5,'telefone','519 9999-9999'),(71,6,'nickname','teste2@email.com'),(72,6,'first_name','andre'),(73,6,'last_name',''),(74,6,'description',''),(75,6,'rich_editing','true'),(76,6,'syntax_highlighting','true'),(77,6,'comment_shortcuts','false'),(78,6,'admin_color','fresh'),(79,6,'use_ssl','0'),(80,6,'show_admin_bar_front','true'),(81,6,'locale',''),(82,6,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(83,6,'wp_user_level','0'),(84,6,'telefone','519 9999-9999'),(85,7,'nickname','teste3@email.com'),(86,7,'first_name','andre'),(87,7,'last_name',''),(88,7,'description',''),(89,7,'rich_editing','true'),(90,7,'syntax_highlighting','true'),(91,7,'comment_shortcuts','false'),(92,7,'admin_color','fresh'),(93,7,'use_ssl','0'),(94,7,'show_admin_bar_front','true'),(95,7,'locale',''),(96,7,'wp_capabilities','a:1:{s:10:\"subscriber\";b:1;}'),(97,7,'wp_user_level','0'),(100,2,'session_tokens','a:1:{s:64:\"6c9d06946ed2231da4c36d65569c4b71914eb158e77e865ff3fd36b91bb091ec\";a:4:{s:10:\"expiration\";i:1731649551;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:21:\"PostmanRuntime/7.42.0\";s:5:\"login\";i:1731476751;}}');
/*!40000 ALTER TABLE `wp_usermeta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-13 15:25:29
